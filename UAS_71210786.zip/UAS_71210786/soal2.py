class CircularQueue() :
    def __init__(self,size):
        self.size = size
        self.queue = [None for i in range(size)]
        self.front = self.rear = -1
    def enqueue(self, data):
        if ((self.rear + 1) % self.size == self.front):
            print("Kasir cuma 3, Silahkan lihat produk lain dulu supaya antrial ga full")
        elif(self.front == -1):
            self.front = 0
            self.rear = 0
            self.queue[self.rear] = data
        else :
            self.rear = (self.rear +1) % self.size
            self.queue[self.rear] = data
    def dequeue(self):
        if(self.front == -1):
            print("Antrian Kosong")
        elif(self.front == self.rear):
            answer = self.queue[self.front]
            self.front = -1
            self.rear = -1
            return answer
        else :
            answer = self.queue[self.front]
            self.front = (self.front + 1)% self.size
            return answer

    def display(self):
        if (self.front == -1):
            print("Antrian kosong")
        elif(self.rear >= self.front):
            print("Yang ada pada antrian adalah: ", end=" ")
            for i in range(self.front, self.rear + 1):
                print(self.queue[i], end=" ")
            print ()
        else:
            for i in range(self.front,self.size):
                print(self.queue[i],end=" ")
            for i in range(0,self.rear + 1):
                print(self.queue[i], end =" ")
                print()
            if ((self.rear + 1) % self.size == self.front):
                print("Antrian Penuh")

#Menambah data
print("Kasir 1 :")
circularQueue = CircularQueue("Shalom")
circularQueue.enqueue("Sindu")
circularQueue.enqueue("Hanif")
circularQueue.enqueue("Dedi")
circularQueue.enqueue("Silvi")
circularQueue.display()

#Menghapus data
circularQueue.dequeue("Shalom")
circularQueue.dequeue("Sindu")
circularQueue.dequeue("Hanif")
circularQueue.dequeue("Dedi")
circularQueue.dequeue("Silvi")
circularQueue.display()

#Menambah data
print("Kasir 2 :")
circularQueue.enqueue("Ghea")
circularQueue.enqueue("Richard")
circularQueue.enqueue("Tiur")
circularQueue.enqueue("Valdo")
circularQueue.enqueue("Risa")
circularQueue.display()

#Menghapus data
circularQueue.dequeue("Ghea")
circularQueue.dequeue("Richard")
circularQueue.dequeue("Tiur")
circularQueue.dequeue("Valdo")
circularQueue.dequeue("Risa")
circularQueue.display()

#Menambah data
print("Kasir 3 :")
circularQueue.enqueue("Alex")
circularQueue.enqueue("Chris")
circularQueue.enqueue("Edwin")
circularQueue.enqueue("Iko")
circularQueue.enqueue("Noel")
circularQueue.display()

#Menambah data tapi penuh
circularQueue = CircularQueue("Shalom")